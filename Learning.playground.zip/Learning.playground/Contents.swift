
public class Node<Value> {
    var value: Value
    var next: Node?
    
    init(value: Value, next: Node? = nil) {
        self.value = value
        self.next = next
    }
}

public struct LinkedList<Value> {
    
    var head: Node<Value>?
    var tail: Node<Value>?
    
    public var isEmpty: Bool {
        head == nil
    }
    
    public mutating func push(_ value: Value) {
        head = Node(value: value, next: head)
        if tail == nil { tail = head }
    }
    
    func logList() {
        if isEmpty {
            print("Empty List")
        } else {
            var temp = head
            while temp != nil {
                print(temp?.value ?? "Empty")
                temp = temp?.next
            }
        }
    }
    
    public mutating func append(value: Value) {
        
        guard !isEmpty else { 
            push(value)
            return
        }
        tail?.next = Node(value: value)
        tail = tail?.next
    }
    
    public func node(at index: Int) -> Node<Value>? {
        var currentNode = head
        var currentIndex = 0
        while currentNode != nil && currentIndex < index {
            currentNode = currentNode?.next
            currentIndex += 1
        }
        return currentNode
    }
    
    public mutating func insert(_ value: Value, after node: Node<Value>) -> Node<Value>? {
      guard tail !== node else {
        append(value: value)
        return tail
      }
      node.next = Node(value: value, next: node.next)
      return node.next
    }
}
